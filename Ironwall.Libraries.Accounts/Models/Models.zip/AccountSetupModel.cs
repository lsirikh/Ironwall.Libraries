﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ironwall.Libaries.Accounts.Models
{
    public class AccountSetupModel : IAccountSetupModel
    {
        public string TableSession => Properties.Settings.Default.TableSession;
        public string TableLogin => Properties.Settings.Default.TableLogin;
        public string TableUser => Properties.Settings.Default.TableUser;
        public string PathDatabase => Properties.Settings.Default.PathDatabase;
        public string NameDatabase => Properties.Settings.Default.NameDatabase;
    }
}
