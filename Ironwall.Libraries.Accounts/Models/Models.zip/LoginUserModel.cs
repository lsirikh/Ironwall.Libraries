﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ironwall.Libaries.Accounts.Models
{
    public class LoginUserModel : ILoginUserModel
    {
        public LoginUserModel()
        {

        }
        public LoginUserModel(string userId, int userLevel, int clientId, int mode, string timeCreated)
        {
            UserId = userId;
            UserLevel = userLevel;
            ClientId = clientId;
            Mode = mode;
            TimeCreated = timeCreated;
        }

        public string UserId { get; set; }
        public int UserLevel { get; set; }
        public int ClientId { get; set; }
        public int Mode { get; set; }
        public string TimeCreated { get; set; }

        public void Insert(string userId, int userLevel, int clientId, int mode, string timeCreated)
        {
            UserId = userId;
            UserLevel = userLevel;
            ClientId = clientId;
            Mode = mode;
            TimeCreated = timeCreated;
        }

        public override string ToString()
        {
            return $"UserId : {UserId}, UserLevel : {UserLevel}, ClientId : {ClientId}, Mode : {Mode}, TimeCreated : {TimeCreated}";
        }
    }
}
