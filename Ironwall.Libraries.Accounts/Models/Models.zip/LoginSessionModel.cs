﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ironwall.Libaries.Accounts.Models
{
    public class LoginSessionModel : ILoginSessionModel
    {
        public string UserId { get; set; }
        public string UserPass { get; set; }
        public string Token { get; set; }
        public string TimeCreated { get; set; }
        public string TimeExpired { get; set; }

        public void Insert(string userId, string userPass, string token, string timeCreated, string timeExpired)
        {
            UserId = userId;
            UserPass = userPass;
            Token = token;
            TimeCreated = timeCreated;
            TimeExpired = timeExpired;
        }
    }
}
