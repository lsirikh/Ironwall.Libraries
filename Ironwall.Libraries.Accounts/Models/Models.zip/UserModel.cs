﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ironwall.Libaries.Accounts.Models
{
    public class UserModel : IUserModel
    {
        #region - Implementations for IUserModel -
        public int Id { get; set; }                 //Not Counted
        public string IdUser { get; set; }          //1
        public int Level { get; set; }              //2
        public string Name { get; set; }            //3
        public bool Used { get; set; }              //4
        public string Password { get; set; }        //5
        #endregion
        #region - Implementations for IAccountModel -
        public string EmployeeNumber { get; set; }  //6
        public string Birth { get; set; }           //7
        public string Phone { get; set; }           //8
        public string Address { get; set; }         //9
        public string EMail { get; set; }           //10
        public string Image { get; set; }           //11
        public string Position { get; set; }        //12
        public string Department { get; set; }      //13
        public string Company { get; set; }         //14
        #endregion
    }
}
