﻿namespace Ironwall.Libaries.Accounts.Models
{
    public interface ILoginSessionModel
    {
        string TimeCreated { get; set; }
        string TimeExpired { get; set; }
        string Token { get; set; }
        string UserId { get; set; }
        string UserPass { get; set; }
    }
}